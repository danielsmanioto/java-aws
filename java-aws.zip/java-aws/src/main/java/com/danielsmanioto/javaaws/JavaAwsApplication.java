package com.danielsmanioto.javaaws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaAwsApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaAwsApplication.class, args);
	}

}
